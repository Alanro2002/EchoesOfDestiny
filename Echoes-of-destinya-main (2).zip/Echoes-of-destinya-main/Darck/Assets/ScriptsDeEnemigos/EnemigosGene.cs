using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemigosGene : MonoBehaviour
{

    public string name;
    public float healthPoints; // vida del enemigo 
    public float speed; //Velocidad del enemigo
    public float damageToGive; //Da�o
}
